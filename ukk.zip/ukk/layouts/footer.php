<footer class="footer py-2 bg-light">
    <div class="container">
        <p class="text-center">UKK RPL 2023 | Nama Peserta | Nama Sekolah</p>
    </div>
</footer>

<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</body>
</html>